$(document).ready(function() {
	
  if (window.Keyboard) {
    Keyboard.hideFormAccessoryBar(true);
  }

  
});